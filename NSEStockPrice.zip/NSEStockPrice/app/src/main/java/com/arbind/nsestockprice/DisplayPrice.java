package com.arbind.nsestockprice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

public class DisplayPrice extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_price);
        try{
            JSONArray result = new JSONArray(getIntent().getStringExtra("result"));
            setResultPage(result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void setResultPage(JSONArray resultParams){
        try {
            TextView currentPrice = findViewById(R.id.textView);
            JSONObject jsonObj = resultParams.getJSONObject(0);
            currentPrice.setText(jsonObj.getString("lastPrice"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
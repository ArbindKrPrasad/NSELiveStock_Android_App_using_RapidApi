package com.arbind.nsestockprice;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class StockList extends AppCompatActivity {
    ListView listView;
    ArrayList stockName, stockCode;
    String newStockName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stock_list);
        Intent i = getIntent();
        final String jsonArray = i.getStringExtra("jsonarray");
        stockName = i.getStringArrayListExtra("stName");
        stockCode = i.getStringArrayListExtra("stCode");
        listView  = findViewById(R.id.listView2);

        ArrayAdapter arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_expandable_list_item_1, stockName);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String stCode = stockCode.get(position).toString();
                try {
                    JSONArray jsonArr = new JSONArray(jsonArray);
                    JSONObject jsonObj = jsonArr.getJSONObject(position);
                    System.out.println(jsonObj.getString("lastPrice"));
                    System.out.println(jsonObj.getString("dayHigh"));
                    System.out.println(jsonObj.getString("dayLow"));
                    System.out.println(jsonObj.getString("change"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });


    }
}
package com.arbind.nsestockprice;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class LaunchActivity extends AppCompatActivity {
    ListView lv;
    String stock = "NIFTY50";
    String apiKey = "700d6561famshb1dc71d0d26b481p10ab4djsn07bc9ce2af16";
    ProgressDialog p;
    String exchangeName;
    String newExchangename;
    ArrayList stName, stCode;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch);

        lv = findViewById(R.id.listView);
        ArrayAdapter arrayAdapter = ArrayAdapter.createFromResource(this, R.array.exchangeList, android.R.layout.simple_list_item_activated_1);
        lv.setAdapter(arrayAdapter);


        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                stName = new ArrayList();
                stCode = new ArrayList();

                exchangeName = parent.getItemAtPosition(position).toString();
                newExchangename = "";
                for(int i=0; i<exchangeName.length(); i++){
                    char ch = exchangeName.charAt(i);
                    if(ch==' '){
                        newExchangename+="%20";
                    } else{
                        newExchangename+=ch;
                    }
                }



                String stockId;
                try {
                    DownloadTask task = new DownloadTask();
                    stockId = newExchangename;

                    String urlWithQuery = "https://latest-stock-price.p.rapidapi.com/prices?Indices="+newExchangename;
                    task.execute(urlWithQuery, exchangeName);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    public class DownloadTask extends AsyncTask<String, Void, String> {
        String selectedStock;
        String result = "";

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            p = new ProgressDialog(LaunchActivity.this);
            p.setMessage("Fetching Stock Information...");
            p.setIndeterminate(false);
            p.setCancelable(false);
        }

        @Override
        protected String doInBackground(String... strings) {
            this.selectedStock = strings[1];

            URL apiURL;
            HttpURLConnection connection = null;

            try{
                apiURL = new URL(strings[0]);
                connection = (HttpURLConnection) apiURL.openConnection();

                connection.setRequestProperty("x-rapidapi-host","latest-stock-price.p.rapidapi.com");
                connection.setRequestProperty("x-rapidapi-key", "700d6561famshb1dc71d0d26b481p10ab4djsn07bc9ce2af16");
                connection.setRequestProperty("useQueryString", "true");

                connection.setRequestMethod("GET");

                InputStream in = connection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);

                //Reading the response line by line
                BufferedReader bufferedReader = new BufferedReader(reader);
                String temp, response = "";
                while((temp=bufferedReader.readLine())!=null){
                    response +=temp;
                }
                return response;

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        String createResultViewParameters(String data){
            onPreExecute();
            JSONArray resultView = new JSONArray();


            try {
                for(int i = 0; i<data.length(); i++){
                    JSONArray jsonArr2 = new JSONArray(data);
                    JSONObject jsonObj = jsonArr2.getJSONObject(i);
                    JSONObject setdata = new JSONObject();
                    setdata.put("lastPrice", jsonObj.getString("lastPrice"));
                    setdata.put("dayHigh", jsonObj.getString("dayHigh"));
                    setdata.put("dayLow", jsonObj.getString("dayLow"));
                    setdata.put("change", jsonObj.getString("change"));
                    stName.add(jsonObj.getString("symbol"));
                    stCode.add(jsonObj.getString("identifier"));
                    resultView.put(setdata);

                }
//                resultView.put(Integer.parseInt("stock"), this.selectedStock);
//
//                JSONObject today = new JSONObject();
//                today.put("lastPrice",Integer.toString(data.getString("lastPrice")));
//                today.put("dayHigh",Integer.toString(data.getInt("dayHigh")));
//                today.put("dayLow",Integer.toString(data.getInt("dayLow")));
//                today.put("change",Integer.toString(data.getInt("change")));
//                resultView.put("today", today);


//                resultView.put("stock", this.selectedStock);
//                JSONArray measurements = (JSONArray) data.get("measurements");
//                JSONObject today = new JSONObject();
//
//                today.put("lastPrice", measurements.getJSONObject(0).getInt("lastPrice"));
//                today.put("dayHigh", measurements.getJSONObject(0).getInt("dayHigh"));
//                today.put("dayLow", measurements.getJSONObject(0).getInt("dayLow"));
//                today.put("change", measurements.getJSONObject(0).getInt("change"));
//                resultView.put("today", today);

            } catch (Exception e) {
                e.printStackTrace();
            }
            return resultView.toString();
        }

        @Override
        protected void onPostExecute(String res) {
            super.onPostExecute(res);
            String res2 =  createResultViewParameters(res);
            p.hide();
            p.dismiss();

            try {
                JSONArray jsona = new JSONArray(res2);
                System.out.println("JAJHHJhjsjhb"+jsona);
                System.out.println(stName.get(0));
                System.out.println(stCode.get(0));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            System.out.println(res);
            try{
                JSONArray resultJson = new JSONArray(res);
                //String status = resultJson.getString("status");
//                if(!status.equals("success")){
//                    p.setMessage("Something went wrong...Please try again");
//                    p.show();
//                    SystemClock.sleep(5000);
//                    p.hide();
//                    return;
//                }

                //JSONObject data = resultJson.getJSONObject("data");

                //JSONObject resultJSON = new JSONObject();
                //resultJSON = createResultViewParameters(data);
                for(int i=0; i<5; i++){
                    System.out.println(stName.get(i));
                }
                Intent intent = new Intent(LaunchActivity.this, StockList.class);
                intent.putExtra("jsonarray", res2);
                intent.putStringArrayListExtra("stName", stName);
                intent.putStringArrayListExtra("stCode", stCode);
                startActivity(intent);
                
            } catch (JSONException e) {
                System.out.println("Exceptation while parsing response");
                e.printStackTrace();
            }
        }
    }
}